<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "pwlmengenaskan";

    $connection = mysqli_connect($host, $username, $password, $database);

    if (!$connection) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

mysqli_set_charset($connection, "utf8mb4");


$query = "SELECT * FROM produk";
$result = mysqli_query($connection, $query);


$products = [];
while ($row = mysqli_fetch_assoc($result)) {
    $products[] = $row;
}


// TODO:
// - Edit kolom-kolom di table keranjang
// - Table keranjang harus menyimpan informasi berupa user_id, produk_id, quantity, subtotal
// - Tampilkan data dari table table keranjang di halaman keranjang atau cart sesuai dengan user yang login
// COntoh QUery: select * from keranjang where user_id = ?;
// user_id ambil dari dta session ketika user login
?>