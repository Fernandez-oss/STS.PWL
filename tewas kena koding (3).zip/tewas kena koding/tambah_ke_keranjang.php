<?php
require_once 'config/db-connection.php';
session_start();

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Silakan login terlebih dahulu"]);
    exit;
}

$produk_id = $_POST['produk_id'] ?? null;
$jumlah = $_POST['jumlah'] ?? 1;
$user_id = $_SESSION['user_id'];

if (!$produk_id) {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
    exit;
}

$check_query = "SELECT id, jumlah FROM keranjang WHERE user_id = ? AND produk_id = ?";
$check_stmt = $connection->prepare($check_query);
$check_stmt->bind_param("ii", $user_id, $produk_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    $existing = $check_result->fetch_assoc();
    $new_jumlah = $existing['jumlah'] + $jumlah;
    
    $update_query = "UPDATE keranjang SET jumlah = ? WHERE id = ?";
    $update_stmt = $connection->prepare($update_query);
    $update_stmt->bind_param("ii", $new_jumlah, $existing['id']);
    
    if ($update_stmt->execute()) {
        echo json_encode(["status" => "success", "action" => "updated", "new_qty" => $new_jumlah]);
    } else {
        echo json_encode(["status" => "error", "message" => $update_stmt->error]);
    }
    
    $update_stmt->close();
} else {
    $insert_query = "INSERT INTO keranjang (user_id, produk_id, jumlah) VALUES (?, ?, ?)";
    $insert_stmt = $connection->prepare($insert_query);
    $insert_stmt->bind_param("iii", $user_id, $produk_id, $jumlah);
    
    if ($insert_stmt->execute()) {
        echo json_encode(["status" => "success", "action" => "inserted"]);
    } else {
        echo json_encode(["status" => "error", "message" => $insert_stmt->error]);
    }
    
    $insert_stmt->close();
}

$check_stmt->close();
?>
