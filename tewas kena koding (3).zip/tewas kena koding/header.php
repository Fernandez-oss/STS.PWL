<?php
include 'config/db-connection.php';
?>

<style>
body{
    margin: 0;
    padding: 0;
}
.header{
    width: 105.9rem;
    height: 100px;
    background-color: #c9c0c0;
    border-bottom: 1px solid black;
    position: relative;
}
.logo{
    width : 65px; 
    height: 60px; 
    margin-left: 10px;
    margin-top: 10px;
}
.hmin{
    font-family: "Black Ops One", sans-serif;
    font-size: 30px;
    margin-top: -65px;
    margin-left: 80px;
    text-shadow: 2px 2px 3px rgba(0,0,0,0.5);
}
.sport{
    font-family: "Black Ops One", sans-serif;
    font-size: 30px;
    margin-top: -30px;
    margin-left: 80px;
    text-shadow: 2px 2px 3px rgba(0,0,0,0.5);
}
.motivasi{
    font-family: "Black Ops One", sans-serif;
    font-size: 15px;
    margin-top: -10px;
    margin-left: 15px;
    text-shadow: 2px 2px 3px rgba(0,0,0,0.5);
}
.search-form {
    display: flex;
    align-items: center;
}
.cari{
    width: 700px;
    height: 40px;
    background-color: #ffffff;
    border: 1px solid black;
    border-radius: 10px;
    margin-top: -110px;
    display: flex;
    margin-left: 500px;
    align-items: center;
    padding: 0 10px;
}
.search-input {
    flex: 1;
    border: none;
    outline: none;
    padding: 8px 15px;
    font-size: 16px;
    background: transparent;
    width: calc(100% - 50px);
}
.search-button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.iconcari{
    width: 35px;
    height: 35px;
    margin-top: 2px;
}
.cari:hover {
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}
.icon1{
    margin-left: 1240px;
    margin-top: -75px;
}
.icon2{
    margin-left: 1320px;
    margin-top: -45px;
}
.icon3{
    margin-left: 1400px;
    margin-top: -45px;
}
.login{
    margin-left: 1500px;
    margin-top: -40px;
}
.user{
    margin-left: 1480px;
    margin-top: -65px;
}
.fani{
    font-family: "Black Ops One", sans-serif;
    font-size: 15px;
    margin-top: -80px;
    margin-left: 90px;
}
</style>

<div class="header">
    <a href="index-user.php">
        <img src="../foto/logo.png" class="logo" alt=""> 
    </a>
    <h1 class="hmin">H-MIN</h1>
    <h1 class="sport">SPORT</h1>
    <h1 class="motivasi">Selalu ada untukmu disetiap saat</h1>

    <form method="GET" action="search.php" class="search-form">
        <div class="cari">
            <input type="text" name="q" placeholder="Cari produk..." class="search-input" 
                   value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
            <button type="submit" class="search-button">
                <img src="../foto/cari.png" alt="Cari" class="iconcari">
            </button>
        </div>
    </form>

    <div class="icon1">
        <a href="keranjang.php">
            <img src="../foto/keranjang.png" class="keranjang" alt="" style="width: 40px;"> 
        </a>
    </div>
    <div class="icon2">
        <a href="notifikasi.php">
            <img src="../foto/notif.png" class="notif" alt="" style="width: 40px;"> 
        </a>
    </div>
    <div class="icon3">
        <a href="tanya.php">
            <img src="../foto/tanya.png" class="tanya" alt="" style="width: 40px;"> 
        </a>
    </div>

    <div class="user">
        <a href="profil.php">
            <img src="../foto/profile.png" alt="" style="width: 80px;">
        </a>
        <div class="fani">
            <h1>
                <?php 
                if (isset($_SESSION['nama'])) {
                    echo htmlspecialchars($_SESSION['nama']);
                } else {
                    echo "Guest";
                }
                ?>
            </h1>
        </div>
    </div>
</div>
