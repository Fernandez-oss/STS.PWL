<?php
session_start();
require_once 'config/db-connection.php';

function getUserName($connection, $user_id) {
  $query = $connection->prepare("SELECT nama FROM users WHERE id = ?");
  $query->bind_param("i", $user_id);
  $query->execute();
  $result = $query->get_result();
  return $result->num_rows > 0 ? $result->fetch_assoc()['nama'] : 'User';
}

function getUserEmail($connection, $user_id) {
  $query = $connection->prepare("SELECT email FROM users WHERE id = ?");
  $query->bind_param("i", $user_id);
  $query->execute();
  $result = $query->get_result();
  return $result->num_rows > 0 ? $result->fetch_assoc()['email'] : 'No Email';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../css/Profil Akun.css">
  <link rel="stylesheet" href="../css/header.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Akun | H-MIN SPORT</title>
  <style>
    body {
      font-family: "Poppins", Arial, sans-serif;
      background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
      margin: 0;
      color: #222;
    }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
  <div class="sidebar">
    <h3>👤 Pengguna</h3>
    <ul>
      <li>Gopay <span>Digunakan</span></li>
      <li>Dana Aktifkan</li>
      <li>Ovo Aktifkan</li>
      <li>Saldo Rp8 x 10<sup>6</sup></li>
    </ul>
    <h4>Kotak Masuk</h4>
    <ul>
      <li>Chat</li>
      <li>Diskusi Produk</li>
      <li>Pesanan Bantuan</li>
      <li>Ulasan</li>
    </ul>
    <h4>Pembelian</h4>
    <ul>
      <li>Menunggu Pembayaran</li>
      <li>Daftar Transaksi</li>
    </ul>
    <h4>Profil Saya</h4>
    <ul>
      <li>Wishlist</li>
      <li>Toko Favorit</li>
      <li>Pengaturan</li>
    </ul>
  </div>

  <div class="content">
    <h2>👤 H-MIN ACC</h2>
    <div class="tabs">
      <div class="active">Biodata Diri</div>
      <a href="profil-alamat.html" style="text-decoration: none; color: inherit;"><div>Daftar Alamat</div></a>
      <a href="profil-keamanan.html" style="text-decoration: none; color: inherit;"><div>Pembayaran</div></a>
      <div>Notifikasi</div>
    </div>

    <div class="profile-box">
      <img src="../foto/profile.png">
      <div class="info">
        <button>Pilih Foto</button>
        <h4>Ubah Biodata Diri</h4>
        <p><b>Nama:</b> <?php
          if (isset($_SESSION['nama'])) {
            echo htmlspecialchars($_SESSION['nama']);
          } else {
            echo "Guest";
          }
        ?></p>
        <p><b>Tanggal Lahir:</b> 02/06/2009</p>
        <p><b>Jenis Kelamin:</b> Copet Pasang</p>
      </div>

      <div class="info">
        <h4>Ubah Kontak</h4>
        <p><b>Email:</b> <?php
          if (isset($_SESSION['user_id'])) {
            $user_email = getUserEmail($connection, $_SESSION['user_id']);
            echo htmlspecialchars($user_email);
          } elseif (isset($_SESSION['nama'])) {
            echo htmlspecialchars($_SESSION['nama']);
          } else {
            echo "Guest";
          }
        ?></p>
        <p><b>No HP:</b> Tambah No HP</p>
      </div>

      <div class="actions">
        <button>Buat Kata Sandi</button>
        <button>Pin H-MIN SPORT</button>
        <button>Verifikasi Instan</button>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>

</body>
</html>
