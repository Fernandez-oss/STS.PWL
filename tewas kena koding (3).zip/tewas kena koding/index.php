<?php
require_once 'config/db-connection.php';

$query_produk = "SELECT * FROM produk ORDER BY RAND() LIMIT 10";
$stmt = $connection->prepare($query_produk);
$stmt->execute();
$result_produk = $stmt->get_result();

$products = [];
while ($row = $result_produk->fetch_assoc()) {
    $products[] = $row;
}
$stmt->close();

$brand = [];

$query_brand = "SELECT * FROM brand ORDER BY RAND() LIMIT 5";
$result_brand = $connection->query($query_brand);

if ($result_brand && $result_brand->num_rows > 0) {
    while ($row = $result_brand->fetch_assoc()) {
        $brand[] = $row;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Homepage</title>
    <link rel="stylesheet" href="css/produk.css" />
    <link rel="stylesheet" href="css/header.css" />

    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
            margin: 0;
            color: #222;
        }
    </style>
</head>
<body>

<div class="header">
    <a href="index-user.php">
        <img src="../foto/logo.png" class="logo" alt="" />
    </a>

    <h1 class="hmin">H-MIN</h1>
    <h1 class="sport">SPORT</h1>
    <h1 class="motivasi">Selalu ada untukmu disetiap saat</h1>

    <div class="cari">
        <img src="../foto/cari.png" alt="" class="iconcari" />
    </div>

    <div class="icon1">
        <a href="../3-icon/keranjang.html">
            <img src="../foto/keranjang.png" class="keranjang" alt="" style="width: 40px;" />
        </a>
    </div>

    <div class="icon2">
        <a href="../3-icon/notifikasi.html">
            <img src="../foto/notif.png" class="notif" alt="" style="width: 40px;" />
        </a>
    </div>

    <div class="icon3">
        <a href="updt-database/brand.php">
            <img src="../foto/tanya.png" class="tanya" alt="" style="width: 40px;" />
        </a>
    </div>

    <div class="login">
            <a href="daftar.php">
                <img src="foto/login.png" alt="" style="width: 150px;" />
            </a>
        </div>

</div>

<h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
    <u>Rekomendasi Brand Dari HMIN</u>
</h2>

<div class="box-container">
    <?php foreach ($brand as $b): ?>
        <a href="produk-brand.php?brand=<?= urlencode($b['brand']) ?>" style="text-decoration: none; color: black;">
            <div class="boxbrand" style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: 0.3s;">
                <img src="foto/<?= htmlspecialchars($b['logo'], ENT_QUOTES, 'UTF-8') ?>" 
                     alt="<?= htmlspecialchars($b['brand'], ENT_QUOTES, 'UTF-8') ?>"
                     style="width: 100%; max-height: 250px; object-fit: cover; border-radius: 10px 10px 0 0;">
            </div>
        </a>
    <?php endforeach; ?>
</div>

<h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
    <u>Rekomendasi Produk Dari HMIN</u>
</h2>

<div class="box-container">
    <?php foreach ($products as $product): ?>
        <a href="produk.php?id=<?= htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8') ?>" style="text-decoration: none; color: black;">
            <div class="box" style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px;">
                <img src="../foto/<?= htmlspecialchars($product['gambar'], ENT_QUOTES, 'UTF-8') ?>" style="width: 250px; height: auto; display: block; border-radius: 10px 10px 0 0;">

                <h3 style="margin: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    <?= htmlspecialchars($product['nama_produk'], ENT_QUOTES, 'UTF-8') ?>
                </h3>

                <p class="harga" style="margin: 5px 10px; font-weight: 700;">
                    Rp <?= number_format($product['harga'], 0, ',', '.') ?>
                </p>

                <?php
                    $rating = ($product['rating'] !== null && $product['rating'] !== '') ? $product['rating'] : '?';
                    $orang = ($product['orang'] !== null && $product['orang'] !== '') ? $product['orang'] : 'Tidak ada';
                ?>

                <div class="produk-rating">
                    Terjual <?= htmlspecialchars($product['terjual'], ENT_QUOTES, 'UTF-8') ?> | ⭐ <?= htmlspecialchars($rating, ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($orang, ENT_QUOTES, 'UTF-8') ?> rating)
                </div>
            </div>
        </a>
    <?php endforeach; ?>
</div>

<?php include 'footer.php'; ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var selector = 'a, button, input[type="button"], input[type="submit"], input[type="image"], .clickable';
    document.querySelectorAll(selector).forEach(function (el) {
        el.addEventListener('click', function (e) {
            e.preventDefault();
            window.location.href = 'daftar.php';
        });
    });

    document.querySelectorAll('.header [role="button"], .header img, .man, .woman, .kids, .shoes, .clothes, .tools').forEach(function(el){
        el.addEventListener('click', function(e){
            e.preventDefault();
            window.location.href = 'daftar.php';
        });
    });
});
</script>

</body>
</html>
