<?php
session_start();
require_once "config/db-connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  $hashed = password_hash($password, PASSWORD_DEFAULT);

  $cek = $connection->prepare("SELECT * FROM users WHERE email = ? OR nama = ?");
  $cek->bind_param("ss", $email, $nama);
  $cek->execute();
  $result = $cek->get_result();

  if ($result->num_rows > 0) {
    $error = "Nama atau Email sudah terdaftar!";
  } else {
    $query = $connection->prepare("INSERT INTO users (nama, email, password) VALUES (?, ?, ?)");
    $query->bind_param("sss", $nama, $email, $hashed);

    if ($query->execute()) {
      $user_id = $connection->insert_id;
      $_SESSION['user_id'] = $user_id;
      $_SESSION['nama'] = $nama;
      
      echo "<script>
          alert('Akun berhasil dibuat! Selamat datang $nama');
          window.location.href = 'index-user.php';
          </script>";
      exit;
    } else {
      $error = "Gagal menyimpan data!";
    }
  }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
  <title>Daftar Akun HMIN SPORT</title>

  <style>
  body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #e8e8e8, #c7c7c7);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }

  .container {
    background: #fff;
    padding: 40px;
    width: 380px;
    border-radius: 18px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    text-align: center;
    animation: fadeIn 0.6s ease;
  }

  @keyframes fadeIn {
    from {opacity: 0; transform: translateY(10px);}
    to {opacity: 1; transform: translateY(0);}
  }

  h2 {
    margin-bottom: 8px;
    font-size: 26px;
    font-weight: 700;
    color: #111;
  }

  .subtitle {
    font-size: 14px;
    color: #666;
    margin-bottom: 20px;
  }

  .form-label {
    display: block;
    text-align: left;
    margin-left: 4px;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-top: 8px;
  }

  input {
    width: 100%;
    padding: 13px;
    margin: 6px 0 12px 0;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 15px;
    transition: 0.2s;
  }

  input:focus {
    border-color: #000;
    box-shadow: 0 0 4px rgba(0,0,0,0.2);
    outline: none;
  }

  button {
    background: black;
    color: white;
    border: none;
    padding: 14px;
    width: 100%;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 5px;
    transition: 0.3s;
  }

  button:hover {
    background: #222;
  }

  .error {
    color: red;
    font-size: 13px;
    margin-bottom: 10px;
  }

  .login-line {
    margin-top: 14px;
    font-size: 14px;
    color: #444;
  }

  .login-line a {
    color: #000;
    font-weight: 700;
    text-decoration: none;
    margin-left: 6px;
  }

  .login-line a:hover {
    text-decoration: underline;
  }

  </style>
</head>

<body>
  <div class="container">

  <h2>Buat Akun Baru</h2>
  <div class="subtitle">Daftar untuk melanjutkan ke HMIN SPORT</div>

  <?php if (!empty($error)) : ?>
    <div class="error"><?= $error ?></div>
  <?php endif; ?>

  <form action="" method="POST">

    <label for="nama" class="form-label">Nama</label>
    <input id="nama" type="text" name="nama" placeholder="Masukkan Nama Lengkap..." required>

    <label for="email" class="form-label">Email</label>
    <input id="email" type="email" name="email" placeholder="Masukkan Email..." required>

    <label for="password" class="form-label">Password</label>
    <input id="password" type="password" name="password" placeholder="Masukkan Password..." required>

    <button type="submit">Daftar</button>

  </form>

  <div class="login-line">
    Sudah punya akun?
    <a href="login.php">Masuk</a>
  </div>

  </div>
</body>
</html>
