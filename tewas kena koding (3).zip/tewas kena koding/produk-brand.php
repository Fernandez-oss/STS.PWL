<?php
session_start();
require_once 'config/db-connection.php';

$selected_brand = isset($_GET['brand']) ? $_GET['brand'] : 'Nike';
$selected_brand_lower = mb_strtolower($selected_brand);

$query = "SELECT * FROM produk WHERE brand = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("s", $selected_brand);
$stmt->execute();
$results = $stmt->get_result();

$products = [];
while ($row = $results->fetch_assoc()) {
    $products[] = $row;
}
$stmt->close();

$query = "SELECT * FROM brand ORDER BY RAND()";
$result = $connection->query($query);

$brand = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $brand[] = $row;
    }
    $result->free();
}

$max_display = 5;
$count = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Homepage</title>
    <link rel="stylesheet" href="css/produk.css" />
    <link rel="stylesheet" href="css/header.css" />
    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
            margin: 0;
            color: #222;
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
    <u>Brand Lain di HMIN</u>
</h2>

<div class="box-container">
    <?php foreach ($brand as $b): ?>
        <?php
        if (mb_strtolower($b['brand']) === $selected_brand_lower) continue;
        if ($count >= $max_display) break;
        $count++;
        ?>
        <a href="?brand=<?= urlencode($b['brand']) ?>" style="text-decoration: none; color: black;">
            <div class="boxbrand" style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px; background: white; transition: 0.3s; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <img src="foto/<?= htmlspecialchars($b['logo']) ?>" alt="<?= htmlspecialchars($b['brand']) ?>" style="width: 100%; height: 250px; object-fit: contain; border-radius: 10px 10px 0 0;" />
            </div>
        </a>
    <?php endforeach; ?>
</div>

<h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
    <u>Produk Dari Brand <?= htmlspecialchars($selected_brand) ?></u>
</h2>

<div class="box-container">
    <?php if (count($products) > 0): ?>
        <?php foreach ($products as $product): ?>
            <a href="produk.php?id=<?= $product['id'] ?>" style="text-decoration: none; color: black;">
                <div class="box" style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px;">
                    <img src="../foto/<?= htmlspecialchars($product['gambar']) ?>" style="width: 100%; height: 250px; object-fit: cover; border-radius: 10px 10px 0 0;" />
                    <h3 style="margin: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?= htmlspecialchars($product['nama_produk']) ?>
                    </h3>
                    <p style="margin: 5px 10px; font-weight: 700;">
                        Rp <?= number_format($product['harga'], 0, ',', '.') ?>
                    </p>
                    <div class="produk-rating">
                        Terjual <?= htmlspecialchars($product['terjual']) ?> | ⭐ <?= htmlspecialchars($product['rating']) ?> (<?= htmlspecialchars($product['orang']) ?> rating)
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="margin-left: 80px; font-size: 28px; font-weight: 700;">
            Maaf Sepertinya Produk Dari Brand ini Masih Tidak ada😢
        </p>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
