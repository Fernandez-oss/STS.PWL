<?php
session_start();
require_once 'config/db-connection.php';

$queryProducts = "SELECT * FROM produk ORDER BY RAND() LIMIT 10";
$stmt = $connection->prepare($queryProducts);
$stmt->execute();
$results = $stmt->get_result();

$products = [];
while ($row = $results->fetch_assoc()) {
    $products[] = $row;
}

$queryBrands = "SELECT * FROM brand ORDER BY RAND() LIMIT 5";
$result = $connection->query($queryBrands);

$brand = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $brand[] = $row;
    }
}

function getUserName($connection, $user_id) {
    $query = $connection->prepare("SELECT nama FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama'] : 'User';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/produk.css">
    <link rel="stylesheet" href="css/header.css">
    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
            margin: 0;
            color: #222;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
        <u>Rekomendasi Brand Dari HMIN</u>
    </h2>

    <div class="box-container">
        <?php foreach ($brand as $b): ?>
            <a href="produk-brand.php?brand=<?= urlencode($b['brand']) ?>" style="text-decoration: none; color: black;">
                <div class="boxbrand" style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: 0.3s;">
                    <img src="foto/<?= htmlspecialchars($b['logo'], ENT_QUOTES, 'UTF-8') ?>" 
                         alt="<?= htmlspecialchars($b['brand'], ENT_QUOTES, 'UTF-8') ?>"
                         style="width: 100%; max-height: 250px; object-fit: cover; border-radius: 10px 10px 0 0;">
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;"><u>Rekomendasi Produk Dari HMIN</u></h2>

    <div class="box-container">
        <?php foreach ($products as $product): ?>
            <a href="produk.php?id=<?= htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8') ?>" style="text-decoration: none; color: black;">
                <div style="width: 250px; border: 1px solid #ccc; border-radius: 10px; padding: 10px; background-color: #f8f8f8f8">
                    <img src="../foto/<?= htmlspecialchars($product['gambar'], ENT_QUOTES, 'UTF-8') ?>" style="width: 250px; height: auto; display: block; border-radius: 10px 10px 0 0;">

                    <h3 style="margin: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?= htmlspecialchars($product['nama_produk'], ENT_QUOTES, 'UTF-8') ?>
                    </h3>

                    <p class="harga" style="margin: 5px 10px; font-weight: 700;">
                        Rp <?= number_format($product['harga'], 0, ',', '.') ?>
                    </p>

                    <?php
                        $rating = ($product['rating'] !== null && $product['rating'] !== '') ? $product['rating'] : '?';
                        $orang = ($product['orang'] !== null && $product['orang'] !== '') ? $product['orang'] : 'Tidak ada';
                    ?>

                    <div class="produk-rating">
                        Terjual <?= htmlspecialchars($product['terjual'], ENT_QUOTES, 'UTF-8') ?> | ⭐ <?= htmlspecialchars($rating, ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($orang, ENT_QUOTES, 'UTF-8') ?> rating)
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
