<?php
session_start();
require_once 'config/db-connection.php';

function getUserName($connection, $user_id) {
    $query = $connection->prepare("SELECT nama FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama'] : 'User';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Notifikasi</title>
    <link rel="stylesheet" href="../css/notifikasi.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link rel="stylesheet" href="../css/header.css">
    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
            margin: 0;
            color: #222;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="halaman"></div>
    <div class="container">
        <h2>Notifikasi</h2>
        <div class="notification-list">
            <div class="notification-item">
                <div class="icon">
                    <i class="fas fa-user"></i>
                </div>
                <div class="content">
                    <div class="title">User</div>
                    <div class="message">Kelas Kink</div>
                </div>
                <div class="time">
                    <div>21:00</div>
                    <div>21/09/2023</div>
                </div>
            </div>
            <div class="notification-item">
                <div class="icon restaurant">
                    <i class="fas fa-utensils"></i>
                </div>
                <div class="content">
                    <div class="title">Restaurant</div>
                    <div class="message">Yapping bgt jir</div>
                </div>
                <div class="time">
                    <div>21:00</div>
                    <div>21/09/2023</div>
                </div>
            </div>
            <div class="notification-item">
                <div class="icon driver">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="content">
                    <div class="title">Driver</div>
                    <div class="message">Bentar lgi sampai king</div>
                </div>
                <div class="time">
                    <div>21:00</div>
                    <div>21/09/2023</div>
                </div>
            </div>
            <div class="notification-item">
                <div class="icon application">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="content">
                    <div class="title">Aplication</div>
                    <div class="message">Who ever read this you're nigger</div>
                </div>
                <div class="time">
                    <div>21:00</div>
                    <div>21/09/2023</div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php'?>
</body>
</html>
