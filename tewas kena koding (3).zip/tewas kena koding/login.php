<?php
require_once "config/db-connection.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $query = $connection->prepare("SELECT * FROM users WHERE email = ?");
  $query->bind_param("s", $email);
  $query->execute();
  $result = $query->get_result();

  if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['nama'] = $user['nama'];
      echo "<script>
        alert('Login berhasil!');
        window.location.href = 'index-user.php';
      </script>";
      exit;
    } else {
      $error = "Password salah!";
    }
  } else {
    $error = "Email tidak terdaftar!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <title>Login HMIN SPORT</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #e8e8e8, #c7c7c7);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      flex-direction: column;
    }
    .user-name {
      margin-bottom: 12px;
      font-size: 18px;
      color: #111;
      background: rgba(255,255,255,0.9);
      padding: 8px 14px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .container {
      background: #fff;
      padding: 40px;
      width: 380px;
      border-radius: 18px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
      text-align: center;
      animation: fadeIn 0.6s ease;
    }
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(10px);}
      to {opacity: 1; transform: translateY(0);}
    }
    h2 {
      margin-bottom: 8px;
      font-size: 26px;
      font-weight: 700;
      color: #111;
    }
    .subtitle {
      font-size: 14px;
      color: #666;
      margin-bottom: 20px;
    }
    input {
      width: 100%;
      padding: 13px;
      margin: 12px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
      transition: 0.2s;
    }
    input:focus {
      border-color: #000;
      box-shadow: 0 0 4px rgba(0,0,0,0.2);
      outline: none;
    }
    .forgot {
      text-align: left;
      margin-bottom: 15px;
    }
    .forgot a {
      text-decoration: none;
      font-size: 13px;
      color: #007bff;
    }
    button {
      background: black;
      color: white;
      border: none;
      padding: 14px;
      width: 100%;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 5px;
      transition: 0.3s;
    }
    button:hover {
      background: #222;
    }
    .error {
      color: red;
      font-size: 13px;
      margin-bottom: 10px;
    }
    .register-text {
      margin-top: 14px;
      font-size: 14px;
      color: #444;
    }
    .register-text a {
      color: #007bff;
      text-decoration: none;
      font-weight: 600;
      margin-left: 6px;
    }
    .register-text a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Login Sekarang!</h2>
    <div class="subtitle">Masuk untuk melanjutkan ke HMIN SPORT</div>
    <?php if (!empty($error)) : ?>
      <div class="error"><?= $error ?></div>
    <?php endif; ?>
    <form action="" method="POST">
      <input type="email" name="email" placeholder="Masukkan Email..." required>
      <input type="password" name="password" placeholder="Masukkan Password.." required>
      <div class="forgot"><a href="#">Lupa Kata Sandi?</a></div>
      <button type="submit">Login</button>
    </form>
    <div class="register-text">
      Belum punya akun?
      <a href="daftar.php" style="color: black">Daftar sekarang</a>
    </div>
  </div>
</body>
</html>
