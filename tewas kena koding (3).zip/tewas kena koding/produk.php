<?php
session_start();
require_once 'config/db-connection.php';

if (!isset($_GET['id'])) {
  die("Produk tidak ditemukan!");
}
$id = $_GET['id'];

$query = "SELECT * FROM produk WHERE id = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
  die("Produk tidak ditemukan!");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="HalamanDeskripsiProduk.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($product['nama_produk']) ?></title>
  <link rel="stylesheet" href="css/desk-produk.css">
  <link rel="stylesheet" href="css/header.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
  <?php include 'header.php'; ?>
  <div class="container">
    <h2 style="color: black">Halaman Deskripsi Produk</h2>
    <div class="product-section">
      <div class="product-image">
        <img src="../foto/<?= htmlspecialchars($product['gambar']) ?>" alt="<?= htmlspecialchars($product['nama_produk']) ?>">
      </div>
      <div class="product-info">
        <div class="product-title"><?= htmlspecialchars($product['nama_produk']) ?></div>
        <div class="product-rating">
          Terjual <?= htmlspecialchars($product['terjual']) ?> | ⭐ <?= htmlspecialchars($product['rating']) ?? '?' ?> (<?= htmlspecialchars($product['orang']) ?? 'Tidak ada' ?> rating)
        </div>
        <div class="product-price">
          Rp<?= number_format($product['harga'], 0, ',', '.') ?>
        </div>
        <div class="size-options">
          <p><b>Pilih ukuran pakaian:</b></p>
          <button>S</button>
          <button>M</button>
          <button>L</button>
          <button class="active">XL</button>
        </div>
      </div>
      <div class="sidebar" data-harga="<?= (int)$product['harga'] ?>" data-stock="<?= (int)$product['stock'] ?>">
        <h4>Atur Jumlah dan Catatan</h4>
        <p>Ukuran: <b>XL</b></p>
        <div class="quantity">
          <button id="tombolKurang">-</button>
          <span id="jumlah">1</span>
          <button id="tombolTambah">+</button>
        </div>
        <p>Stock: <?= (int)$product['stock'] ?></p>
        <p class="subtotal">Subtotal: Rp<span id="subtotal"><?= number_format($product['harga'], 0, ',', '.') ?></span></p>
        <div class="buttons">
          <button class="btn btn-primary">Beli</button>
          <button class="btn btn-outline" onclick="tambahKeranjang(<?= $product['id'] ?>)">Keranjang</button>
          <script>
            function tambahKeranjang(produk_id) {
              let jumlah = document.getElementById("jumlah").textContent;
              fetch("tambah_ke_keranjang.php", {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "produk_id=" + produk_id + "&jumlah=" + jumlah
              })
              .then(response => response.text())
              .then(data => {
                Swal.fire({
                  icon: 'success',
                  title: 'Berhasil!',
                  text: 'Produk ditambahkan ke keranjang!',
                  showConfirmButton: false,
                  timer: 1500
                });
              })
              .catch(error => {
                console.error("Error:", error);
              });
            }
          </script>
        </div>
      </div>
    </div>
    <div class="product-details">
      <h4>Detail Produk</h4>
      <p>Kondisi: <?= ($product['kondisi']) ?? 'Tidak ada' ?></p>
      <p>Minimal Pemesanan: 1 buah</p>
      <p><?= htmlspecialchars($product['deskripsi'] ?? 'Belum ada deskripsi produk.') ?></p>
    </div>
    <div class="review">
      <h4>Ulasan Pembeli</h4>
      <p><span class="stars">★★★★☆</span> 4.8 / 5.0 — 100% pembeli merasa puas</p>
      <p>5 ★</p>
      <div class="bar"><div class="bar-fill" style="width: 90%;"></div></div>
      <p>4 ★</p>
      <div class="bar"><div class="bar-fill" style="width: 30%;"></div></div>
      <p>3 ★</p>
      <div class="bar"><div class="bar-fill" style="width: 10%;"></div></div>
    </div>
  </div>
  <?php include 'footer.php'; ?>
  <script>
    const sidebar = document.querySelector('.sidebar');
    const hargaProduk = parseInt(sidebar.dataset.harga);
    const stock = parseInt(sidebar.dataset.stock);
    const tombolTambah = document.getElementById('tombolTambah');
    const tombolKurang = document.getElementById('tombolKurang');
    const jumlahElement = document.getElementById('jumlah');
    const subtotalElement = document.getElementById('subtotal');
    let jumlah = 1;

    function updateDisplay() {
      jumlahElement.textContent = jumlah;
      subtotalElement.textContent = (hargaProduk * jumlah).toLocaleString('id-ID');
    }

    tombolTambah.addEventListener('click', () => {
      if (jumlah < stock) {
        jumlah++;
        updateDisplay();
      } else {
        alert('Stok tidak mencukupi!');
      }
    });

    tombolKurang.addEventListener('click', () => {
      if (jumlah > 1) {
        jumlah--;
        updateDisplay();
      }
    });

    updateDisplay();

    function tambahKeranjang(produk_id) {
      let jumlah = parseInt(document.getElementById("jumlah").textContent);
      fetch("tambah_ke_keranjang.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "produk_id=" + produk_id + "&jumlah=" + jumlah
      })
      .then(res => res.json())
      .then(data => {
        if (data.status === "success") {
          if (data.action === "updated") {
            Swal.fire({
              icon: 'info',
              title: 'Produk Diupdate!',
              text: `Produk sudah ada di keranjang! Sekarang ada ${data.new_qty} item`,
              showConfirmButton: false,
              timer: 2000
            });
          } else {
            Swal.fire({
              icon: 'success',
              title: 'Berhasil!',
              text: 'Produk ditambahkan ke keranjang!',
              showConfirmButton: false,
              timer: 1500
            });
          }
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Error: ' + data.message,
            showConfirmButton: false,
            timer: 2000
          });
        }
      })
      .catch(error => {
        console.error("Error:", error);
        Swal.fire({
          icon: 'error',
          title: 'Error!',
          text: 'Terjadi kesalahan sistem',
          showConfirmButton: false,
          timer: 2000
        });
      });
    }
  </script>
</body>
</html>
