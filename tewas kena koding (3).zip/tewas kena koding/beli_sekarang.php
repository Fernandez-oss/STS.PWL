<?php
session_start();
require_once 'config/db-connection.php';

header("Content-Type: application/json");

$user_id = $_SESSION['user_id'];

try {
    $query = "DELETE FROM keranjang WHERE user_id = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Keranjang berhasil dikosongkan"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal mengosongkan keranjang"]);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
