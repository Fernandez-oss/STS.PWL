<?php
require_once 'config/db-connection.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "
    SELECT 
        k.id,
        k.jumlah AS qty,
        p.nama_produk AS nama,
        p.harga,
        p.gambar
    FROM keranjang k
    JOIN produk p ON k.produk_id = p.id
    WHERE k.user_id = ? 
";

$stmt = $connection->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
$total = 0;

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
        $total += $row['harga'] * $row['qty'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="../css/keranjang.css" />
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/profil.css">
</head>
<body>

    <?php include 'header.php'; ?>

<div class="text">
    <div class="container">
        <h2>Keranjang</h2>

        <div class="keranjang-list">

            <?php if (count($items) == 0): ?>
            <div class="keranjang-item">
                <div class="keranjang-content" style="flex: 1; justify-content: center; text-align: center;">
                    <div class="text-content">
                        <h3>Wah, keranjang belanjamu kosong</h3>
                        <p>Yuk, isi dengan barang-barang impianmu!</p>
                        <div class="tombol-container">
                            <a href="index-user.php">
                                <button class="btn-mulai">Mulai Belanja</button>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="ringkasan-belanja">
                    <h4>Ringkasan belanja</h4>
                    <div class="total-section">
                        <span class="total-label">Total</span>
                        <span class="total-harga">Rp 0</span>
                    </div>
                    <button class="btn-promo">Makin hemat pakai promo</button>
                    <button class="btn-beli" disabled>Beli</button>
                </div>
            </div>

            <?php else: ?>

            <div class="keranjang-item">
                <div style="flex: 1; display: flex; flex-direction: column; gap: 15px;">
                    <?php foreach ($items as $item): ?>
                    <div class="keranjang-content">
                        <img src="../foto/<?= $item['gambar'] ?>" 
                             alt="<?= $item['nama'] ?>" 
                             class="gambar-produk">

                        <div class="text-content">
                            <h3><?= $item['nama'] ?></h3>
                            <p class="harga">Harga: Rp <?= number_format($item['harga'], 0, ',', '.')?></p>
                            <p class="qty">Qty: <?= $item['qty'] ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

<div class="ringkasan-belanja">
    <h4>Ringkasan belanja</h4>
    
    <div class="total-section">
        <span class="total-label">Total</span>
        <span class="total-harga">Rp <?= number_format($total, 0, ',', '.') ?></span>
    </div>
    
    <div class="promo-section">
        <button class="btn-promo">Makin hemat pakai promo</button>
    </div>
    
    <button class="btn-beli" onclick="beliSekarang()">Beli Sekarang</button>

    <a href="index-user.php">
        <button class="btn-cari-lain">Cari Produk Lain</button>
    </a>
</div>
            </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function beliSekarang() {
    Swal.fire({
        title: 'Konfirmasi Pembelian',
        text: 'Yakin ingin membeli semua produk di keranjang?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#505a70',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Beli Sekarang!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('beli_sekarang.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Pembelian berhasil! Keranjang telah dikosongkan.',
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: 'Terjadi kesalahan: ' + data.message
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Terjadi kesalahan sistem'
                });
            });
        }
    });
}
</script>
</body>
</html>
