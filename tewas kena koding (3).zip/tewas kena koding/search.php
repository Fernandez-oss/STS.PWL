<?php
session_start();
include 'config/db-connection.php';

$search_query = "";
$results = [];

function getUserName($connection, $user_id) {
    $query = $connection->prepare("SELECT nama FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama'] : 'User';
}

if (isset($_GET['q']) && !empty(trim($_GET['q']))) {
    $search_query = trim($_GET['q']);
    $sql = "SELECT * FROM produk WHERE (nama_produk LIKE ? OR deskripsi LIKE ?) ORDER BY nama_produk ASC";
    $stmt = mysqli_prepare($connection, $sql);
    
    if ($stmt) {
        $search_term = "%" . $search_query . "%";
        mysqli_stmt_bind_param($stmt, "ss", $search_term, $search_term);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        while ($row = mysqli_fetch_assoc($result)) {
            $results[] = $row;
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo "Error dalam prepared statement: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pencarian - H-MIN SPORT</title>
    <link rel="stylesheet" href="css/produk.css">
    <link rel="stylesheet" href="css/header.css">
    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
            margin: 0;
            color: #222;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <h2 style="margin-left: 80px; font-size: 30px; margin-top: 50px;">
        <u>Hasil Pencarian "<?php echo htmlspecialchars($search_query); ?>"</u>
    </h2>
    <?php if (!empty($results)): ?>
        <div class="box-container">
            <?php foreach ($results as $product): ?>
                <a href="produk.php?id=<?= htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8') ?>" style="text-decoration: none; color: black;">
                    <div class="box">
                        <img src="../foto/<?= htmlspecialchars($product['gambar'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($product['nama_produk'], ENT_QUOTES, 'UTF-8') ?>">
                        <h3 style="margin: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            <?= htmlspecialchars($product['nama_produk'], ENT_QUOTES, 'UTF-8') ?>
                        </h3>
                        <p class="harga" style="margin: 5px 10px; font-weight: 700;">
                            Rp <?= number_format($product['harga'], 0, ',', '.') ?>
                        </p>
                        <?php
                            $rating = ($product['rating'] !== null && $product['rating'] !== '') ? $product['rating'] : '?';
                            $orang = ($product['orang'] !== null && $product['orang'] !== '') ? $product['orang'] : 'Tidak ada';
                        ?>
                        <div class="produk-rating">
                            Terjual <?= htmlspecialchars($product['terjual'], ENT_QUOTES, 'UTF-8') ?> | ⭐ <?= htmlspecialchars($rating, ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($orang, ENT_QUOTES, 'UTF-8') ?> rating)
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 60px 20px; color: #666; font-size: 18px;">
            <p>😔 Tidak ada produk yang ditemukan untuk "<?php echo htmlspecialchars($search_query); ?>"</p>
            <p>Silakan coba dengan kata kunci lain yang lebih umum.</p>
        </div>
    <?php endif; ?>
    <?php include 'footer.php'; ?>
</body>
</html>
