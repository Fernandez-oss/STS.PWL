<?php
session_start();
require_once 'config/db-connection.php';

function getUserName($connection, $user_id) {
  $query = $connection->prepare("SELECT nama FROM users WHERE id = ?");
  $query->bind_param("i", $user_id);
  $query->execute();
  $result = $query->get_result();
  return $result->num_rows > 0 ? $result->fetch_assoc()['nama'] : 'User';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>HMIN SPORT Indonesia Info</title>
  <link rel="stylesheet" href="../css/header.css">
  <style>
  body {
    font-family: "Poppins", Arial, sans-serif;
    background: linear-gradient(to bottom, #f7f5f5, #eaeaea);
    margin: 0;
    color: #222;
  }
  </style>
</head>
<body>
<?php include 'header.php'; ?>

<main>
  HMIN SPORT Indonesia merupakan pelopor dalam belanja perlengkapan olahraga online, menghadirkan beragam brand lokal maupun internasional yang terus bertambah untuk konsumen di seluruh Indonesia. Awali perjalanan gaya hidup sehat Anda dengan memiliki perlengkapan olahraga dasar yang penting, seperti kaos olahraga, celana training, sepatu lari, hingga jersey favorit. Temukan juga berbagai produk untuk mendukung aktivitas olahraga, mulai dari fitness, futsal, basket, hingga badminton, semuanya tersedia dalam satu platform.<br><br>
  Tampil lebih percaya diri saat berolahraga dengan koleksi perlengkapan lengkap dari HMIN SPORT, mulai dari sepatu olahraga dengan berbagai pilihan model, tas gym yang praktis, hingga aksesoris penunjang seperti botol minum, smartwatch, sarung tangan, dan pelindung olahraga. Tidak hanya itu, HMIN SPORT juga menghadirkan koleksi perlengkapan untuk segala kebutuhan, baik untuk olahraga dalam ruangan maupun luar ruangan, dari latihan ringan hingga kompetisi.<br><br>
  Sebagai pusat belanja perlengkapan olahraga online terbesar di Indonesia, HMIN SPORT selalu berkomitmen untuk memberikan produk asli, berkualitas, serta layanan terbaik bagi konsumen. Dengan navigasi pencarian yang mudah, katalog produk yang lengkap, sistem pembayaran aman, dan pengiriman cepat, pengalaman berbelanja Anda akan menjadi lebih praktis dan menyenangkan.<br><br>
  HMIN SPORT juga menghadirkan promo dan diskon menarik setiap minggunya, serta penawaran spesial saat momen besar seperti Harbolnas. Tidak perlu ragu, karena semua produk yang tersedia di HMIN SPORT bergaransi 100% original dan dilengkapi dengan kemudahan pengembalian barang hingga 30 hari di seluruh Indonesia.<br><br>
  Temukan ribuan brand olahraga favorit Anda hanya di HMIN SPORT Indonesia, tempat terbaik untuk melengkapi kebutuhan olahraga sekaligus mendukung gaya hidup sehat dan aktif setiap hari.
</main>

<?php include 'footer.php'; ?>
</body>
</html>
