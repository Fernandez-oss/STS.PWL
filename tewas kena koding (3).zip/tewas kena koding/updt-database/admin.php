<?php
require_once '../config/db-connection.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $brand = $_POST['brand'];
    $rating = $_POST['rating'] ?? null;
    $orang = $_POST['orang'] ?? null;
    $terjual = $_POST['terjual'] ?? 0;
    $deskripsi = $_POST['deskripsi'];
    $kondisi = $_POST['kondisi'];

    // PROSES UPLOAD GAMBAR - YANG DIPERBAIKI
    $gambar = null;
    if (!empty($_FILES['gambar']['name'])) {
        // PAKAI NAMA FILE ASLI (termasuk ekstensi .jpg, .png, dll)
        $gambar = $_FILES["gambar"]["name"];
        $target_file = "foto/" . $gambar;
        
        // pindahkan file ke folder foto
        move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file);
    }

    // simpan ke database
    $query = "INSERT INTO produk (nama_produk, harga, brand, rating, orang, terjual, gambar, deskripsi, kondisi)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("sdssiisss", $nama_produk, $harga, $brand, $rating, $orang, $terjual, $gambar, $deskripsi, $kondisi);

    if ($stmt->execute()) {
        echo "<script>alert('Produk berhasil ditambahkan!'); window.location.href='../index-user.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan produk!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 40px;
        }
        form {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            width: 400px;
            margin: 0 auto;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        h2 { text-align: center; }
    </style>
</head>
<body>

<h2>Tambah Produk Baru</h2>
<form method="POST" enctype="multipart/form-data">
    <label>Nama Produk:</label>
    <input type="text" name="nama_produk" required>

    <label>deskripsi:</label>
    <input type="text" name="deskripsi" required>

    <label>kondisi produk:</label>
    <input type="text" name="kondisi" required>

    <label>Harga:</label>
    <input type="number" name="harga" required>

    <label>Brand:</label>
    <input type="text" name="brand" required>

    <label>Rating (opsional):</label>
    <input type="number" step="0.1" name="rating" placeholder="contoh: 4.8">

    <label>Total Rating (opsional):</label>
    <input type="number" step="0.1" name="orang">

    <label>Terjual:</label>
    <input type="number" name="terjual" required>

    <label>Gambar Produk:</label>
    <input type="file" name="gambar" accept="image/*" required>

    <button type="submit">Tambah Produk</button>
</form>


        

</body>
</html>
