<?php
require_once '../config/db-connection.php';

// cek kalau form disubmit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $brand = $_POST['brand'];

    // proses upload logo
    $logo = null;
    if (!empty($_FILES['logo']['name'])) {
        $target_dir = "foto/";
        // buat folder jika belum ada
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $logo = basename($_FILES["logo"]["name"]);
        $target_file = $target_dir . $logo;

        // pindahkan file ke folder foto
        if (!move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file)) {
            echo "<script>alert('Gagal mengupload logo!');</script>";
            exit;
        }
    }

    // simpan ke tabel brand
    $query = "INSERT INTO brand (brand, logo) VALUES (?, ?)";
    $stmt = $connection->prepare($query);

    if ($stmt) {
        $stmt->bind_param("ss", $brand, $logo);
        if ($stmt->execute()) {
            echo "<script>alert('Brand berhasil ditambahkan!'); window.location.href='index-user.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan brand: " . $stmt->error . "');</script>";
        }
    } else {
        echo "<script>alert('Query error: " . $connection->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Brand</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            padding: 40px;
        }
        form {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            width: 400px;
            margin: 0 auto;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        h2 { text-align: center; }
    </style>
</head>
<body>

<h2>Tambah Brand Baru</h2>
<form method="POST" enctype="multipart/form-data">
    <label>brand Brand:</label>
    <input type="text" name="brand" required>

    <label>logo Brand:</label>
    <input type="file" name="logo" accept="image/*" required>

    <button type="submit">Tambah Brand</button>
</form>

</body>
</html>
